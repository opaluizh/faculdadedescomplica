// Imagine que você é um entregador de pizzas em uma cidade com várias ruas numeradas de 1 a 10.
// Você tem que entregar uma pizza em cada rua, começando da rua 1 até a rua 10.

// Aqui, usaremos um loop for para simular esse processo:

for (let rua = 1; rua <=10; rua++) {
    console.log("Entrega feita na rua: ", rua);
}